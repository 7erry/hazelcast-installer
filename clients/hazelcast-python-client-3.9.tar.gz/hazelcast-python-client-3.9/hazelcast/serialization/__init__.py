"""
Serialization Module
"""
from hazelcast.serialization.bits import *
from hazelcast.serialization.service import SerializationServiceV1
