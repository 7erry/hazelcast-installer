"""
Hazelcast Portable Serialization Module
"""