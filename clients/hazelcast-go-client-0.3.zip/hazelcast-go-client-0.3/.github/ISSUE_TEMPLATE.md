Go version:
Hazelcast Go Client version:
Hazelcast server version:
Number of the clients:
Cluster size, i.e. the number of Hazelcast cluster members:
OS version : Windows/Linux/OSX

#### Expected behaviour


#### Actual behaviour


#### Steps to reproduce the behaviour