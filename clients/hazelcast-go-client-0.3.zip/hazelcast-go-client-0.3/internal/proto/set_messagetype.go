// Copyright (c) 2008-2018, Hazelcast, Inc. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License")
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package proto

const (
	setSize                = 0x0601
	setContains            = 0x0602
	setContainsAll         = 0x0603
	setAdd                 = 0x0604
	setRemove              = 0x0605
	setAddAll              = 0x0606
	setCompareAndRemoveAll = 0x0607
	setCompareAndRetainAll = 0x0608
	setClear               = 0x0609
	setGetAll              = 0x060a
	setAddListener         = 0x060b
	setRemoveListener      = 0x060c
	setIsEmpty             = 0x060d
)
