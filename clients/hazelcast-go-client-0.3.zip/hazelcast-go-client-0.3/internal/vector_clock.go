// Copyright (c) 2008-2018, Hazelcast, Inc. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License")
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package internal

import (
	"sync"

	"github.com/hazelcast/hazelcast-go-client/internal/proto"
	"github.com/hazelcast/hazelcast-go-client/serialization"
)

const (
	fID                = 0
	vectorClockClassID = 43
)

type vectorClock struct {
	mutex             sync.RWMutex //guards replicaTimestamps
	replicaTimestamps map[string]int64
}

func newVectorClock() *vectorClock {
	return &vectorClock{replicaTimestamps: make(map[string]int64)}
}

func (*vectorClock) FactoryID() int32 {
	return fID
}

func (*vectorClock) ClassID() int32 {
	return vectorClockClassID
}

func (v *vectorClock) WriteData(output serialization.DataOutput) (err error) {
	v.mutex.RLock()
	defer v.mutex.RUnlock()
	output.WriteInt32(int32(len(v.replicaTimestamps)))
	for key, value := range v.replicaTimestamps {
		output.WriteUTF(key)
		output.WriteInt64(value)
	}
	return
}

func (v *vectorClock) ReadData(input serialization.DataInput) error {
	stateSize, err := input.ReadInt32()
	if err != nil {
		return err
	}
	for i := int32(0); i < stateSize; i++ {
		replicaID, err := input.ReadUTF()
		if err != nil {
			return err
		}
		timestamp, err := input.ReadInt64()
		if err != nil {
			return err
		}
		v.replicaTimestamps[replicaID] = timestamp
	}
	return nil
}

func (v *vectorClock) EntrySet() (entrySet []*proto.Pair) {
	v.mutex.RLock()
	defer v.mutex.RUnlock()
	entrySet = make([]*proto.Pair, len(v.replicaTimestamps))
	i := 0
	for key, value := range v.replicaTimestamps {
		entrySet[i] = proto.NewPair(key, value)
		i++
	}
	return entrySet
}

func (v *vectorClock) IsAfter(other *vectorClock) (isAfter bool) {
	anyTimestampGreater := false
	for replicaID, otherReplicaTimestamp := range other.replicaTimestamps {
		localReplicaTimestamp, initialized := v.TimestampForReplica(replicaID)
		if !initialized || localReplicaTimestamp < otherReplicaTimestamp {
			return false
		} else if localReplicaTimestamp > otherReplicaTimestamp {
			anyTimestampGreater = true
		}
	}
	v.mutex.RLock()
	defer v.mutex.RUnlock()
	return anyTimestampGreater || (len(v.replicaTimestamps) > len(other.replicaTimestamps))
}

func (v *vectorClock) SetReplicaTimestamp(replicaID string, timestamp int64) {
	v.mutex.Lock()
	v.replicaTimestamps[replicaID] = timestamp
	v.mutex.Unlock()
}

func (v *vectorClock) TimestampForReplica(replicaID string) (int64, bool) {
	v.mutex.RLock()
	val, ok := v.replicaTimestamps[replicaID]
	v.mutex.RUnlock()
	return val, ok
}
