/* tslint:disable */
export class FlakeIdGeneratorMessageType {
    static FLAKEIDGENERATOR_NEWIDBATCH = 0x1f01;
}
