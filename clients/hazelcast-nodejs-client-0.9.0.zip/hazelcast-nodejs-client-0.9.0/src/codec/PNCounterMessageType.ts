/* tslint:disable */
export class PNCounterMessageType {
    static PNCOUNTER_GET = 0x2001;
    static PNCOUNTER_ADD = 0x2002;
    static PNCOUNTER_GETCONFIGUREDREPLICACOUNT = 0x2003;
}
