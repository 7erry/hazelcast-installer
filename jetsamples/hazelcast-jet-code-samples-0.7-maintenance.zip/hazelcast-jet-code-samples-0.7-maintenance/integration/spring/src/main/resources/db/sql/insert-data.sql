INSERT INTO users VALUES (1, 'ali', 'ali@hazelcast.com');
INSERT INTO users VALUES (2, 'can', 'can@hazelcast.com');
INSERT INTO users VALUES (3, 'marko', 'marko@hazelcast.com');
INSERT INTO users VALUES (4, 'vilo', 'vilo@hazelcast.com');