#!/bin/sh

mvn clean install -DskipTests
cf push
