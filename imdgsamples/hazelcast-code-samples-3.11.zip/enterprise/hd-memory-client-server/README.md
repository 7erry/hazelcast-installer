# Hazelcast HD Memory Example

Requires a Hazelcast Enterprise licence.  Download a trial key from

http://hazelcast.com/hazelcast-enterprise-trial/

## Introduction

Demonstrates Hazelcast HD Memory by running a small heap JVM cluster server and referencing 3gb of native memory.
