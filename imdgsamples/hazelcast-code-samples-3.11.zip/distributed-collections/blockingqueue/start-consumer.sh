#!/bin/sh

java -cp target/lib/*:target/classes ConsumerMember
