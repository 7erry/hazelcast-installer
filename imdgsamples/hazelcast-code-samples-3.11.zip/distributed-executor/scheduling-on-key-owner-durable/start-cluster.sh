#!/bin/sh

java -cp target/lib/*:target/classes Cluster
